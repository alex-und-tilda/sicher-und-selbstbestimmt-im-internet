# Änderung 2026-06-04: Datenschutz, Aufräumen, Robustheit

## 1. Schrift lokal gehostet (Datenschutz / KDG)
- Vorher: Atkinson Hyperlegible wurde live von fonts.googleapis.com /
  fonts.gstatic.com geladen -> IP-Abfluss an Google, im Widerspruch
  zum Versprechen "kein Tracking, nichts wird gespeichert".
- Jetzt: Schrift liegt lokal als assets/fonts/atkinson-hyperlegible-400.woff2
  und -700.woff2 (SIL OFL 1.1). Eingebunden per @font-face am Anfang
  von styles.css. preconnect- und Google-<link>-Zeilen aus index.html entfernt.
- Effekt: keine Drittanbieter-Verbindung mehr beim Laden der Seite.

## 2. Verwaiste Mehrfach-Assets entfernt
- SVGs lagen vierfach (Root, icons/, illustrations/, assets/).
- Der Code referenziert ausschliesslich assets/.
- Gelöscht: 26 Root-SVGs, Ordner icons/, illustrations/, brand/,
  zwei Root-Logos. Bild-Assets von 84 auf 28 reduziert.
- Wartung: Logo-/Icon-Wechsel jetzt nur noch an einer Stelle.

## 3. Prozess-Doku archiviert
- 55 AENDERUNG_*/_PRUEFBERICHT/ROLLBACK/AUDIT-Dateien nach _verlauf/ verschoben.
- Im Root bleiben: README.md, SECURITY.md, TESTPLAN.md, DATENSCHUTZ_HINWEIS.md.

## 4. Fallback ohne JavaScript
- index.html: <noscript>-Hinweis in Einfacher Sprache ergaenzt
  (vorher leere weisse Seite, wenn JS aus war).

## Geprueft
- Alle in app.js/topics.js referenzierten Icons und Illustrationen vorhanden.
- node --check app.js / topics.js: Syntax OK.
- Keine toten Verweise in HTML. Null Google-Treffer in index.html.

## Offen (bewusst NICHT angefasst)
- styles.css: 6271 Zeilen, ~1142x !important -> spaetere Entruempelung,
  zu riskant ohne Regressionstests.
- frank-runge-*.html / projekte-*.html: SEO-Seiten ggf. trennen.
- Inhaltliche Idee: eigenes Thema KI-Betrug / Deepfakes / Fake-Sprachnachrichten.
- Offizielle Leichte Sprache: Zielgruppen-Pruefung + Logo-Klaerung.

## 6. Neues Thema "KI und Betrug" (Entwurf)
- 8. Lernthema ergaenzt, eingeordnet vor "Hilfe bei Problemen".
- 11 Lektionen in Einfacher Sprache (EU/Inclusion-Europe-Regeln):
  Was ist KI / KI als Werkzeug / falsche Bilder (Deepfake) / falsche Videos /
  falsche Stimmen / Enkel-Trick / falsche Nachrichten und Chat / So pruefe ich /
  Handlungsplan / Zusammenfassung. Mit Uebungen (practice), 9 Quizfragen,
  Merk-Karte (memoryRules + helpQuestions), Mini-Frage, certificateGoals,
  shortLessonIndexes, QR-Links.
- Neues Icon assets/icons/ki.svg (Roboterkopf, Linien-Stil der vorhandenen Icons).
- Neue Illustration assets/illustrations/ki-betrug.svg (480x360, Markenfarben,
  Telefon-Mockup "ECHT ODER FALSCH?").
- Themenfarbe in app.js ergaenzt: ki-betrug -> Violett (#6A4FB3).
- Verifikation: node-Ladecheck (9 Themen, korrekte Reihenfolge, alle Felder),
  alle genutzten Icons + Illustration vorhanden, Headless-Render ohne JS-Fehler
  (Themenwahl, Lektion, Quiz, Merk-Karte).

## OFFEN fuer dieses Thema (wichtig)
- Inhalt ist Einfache Sprache, NICHT geprueft. Vor Einsatz: Pruefung durch
  Zielgruppen-Panel (wie bei den anderen Inhalten). Erst danach ggf. offizielles
  Leichte-Sprache-Logo.
- Fachliche Gegenlesung der Betrugsmaschen (Enkel-Trick, Voice-Cloning) durch
  Beratungsstelle empfohlen, da sich Maschen schnell aendern.

## 7. SEO-/Profil-Seiten von der Lern-App getrennt
- 13 SEO-/Profil-/Projektseiten (frank-runge-*, projekte-*, ersteller,
  barrierearme-*, datenschutz-social-media-*) nach info/ verschoben.
- Im Wurzelverzeichnis liegt jetzt nur noch index.html (die Lern-App).
- Pfade in den verschobenen Seiten angepasst: index.html -> ../index.html,
  styles.css -> ../styles.css. Cross-Links untereinander bleiben gueltig
  (alle im selben Ordner). CSS-Schrift laedt weiter korrekt, da url() in
  styles.css relativ zur CSS-Datei (Wurzel) aufgeloest wird.
- App verlinkt die Profilwelt nur noch ueber einen dezenten Footer-Link
  -> info/ersteller.html (app.js).
- sitemap.xml: 13 Eintraege auf info/ umgestellt, Start-URL unveraendert.
  Google findet die Seiten weiter; Lernende landen nicht mehr darin.
- robots.txt unveraendert (Allow: / deckt info/ ab).
- Verifikation: alle Links in index.html, app.js und allen 13 info-Seiten
  zeigen auf existierende Dateien (0 tote Links). HTTP 200 fuer index,
  info-Seiten, ../styles.css, sitemap. App-Render ohne JS-Fehler,
  Footer-Link = info/ersteller.html.
